﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony
{
    public interface ISmartPhone
    {
        public void Browse(string URL);


        public void Call(string number);

    }
}
