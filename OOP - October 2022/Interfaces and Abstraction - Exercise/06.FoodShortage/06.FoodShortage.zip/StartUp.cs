﻿using _06.FoodShortage.Core;
using System;

namespace _06.FoodShortage
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
