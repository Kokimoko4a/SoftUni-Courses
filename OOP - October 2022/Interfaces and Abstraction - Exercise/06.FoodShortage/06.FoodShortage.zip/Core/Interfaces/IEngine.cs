﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.FoodShortage.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
