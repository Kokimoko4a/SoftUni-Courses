﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm
{
    public class Vegetables : Food
    {
    }
}
