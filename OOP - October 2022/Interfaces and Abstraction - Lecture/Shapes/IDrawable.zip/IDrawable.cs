﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    internal interface IDrawable
    {
        public void Draw();

    }
}
