﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    internal class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
