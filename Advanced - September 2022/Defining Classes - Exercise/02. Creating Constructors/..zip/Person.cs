﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Person
    {
        public Person()
        {
            this.Pat = 1;
            this.Name = "No name";
        }
        public Person(int age)
        {
            this.Pat = age;
            this.Name = "No name";
        }
        public Person(string name, int age)
        {
            this.Name = name;
            this.Pat = age;
        }

        private int pat;
        private string name;

        public int Pat
        {
            get { return pat; }
            set { pat = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }
}
