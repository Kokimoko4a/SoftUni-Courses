﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Pokemon
    {
        public int Health { get; set; }
        public string Element { get; set; }
        public string Name { get; set; }
    }
}
