﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FishingNet
{
    public class Fish
    {
        public Fish(string fishType,double length,double weight)
        {
            FishType = fishType;
            Length = length;
            Weight = weight;
        }

        public double Weight { get; set; }
        public double Length { get; set; }
        public string FishType { get; set; }

        public override string ToString()
        {
            return $"There is a {FishType}, {Length} cm. long, and {Weight} gr. in weight.";
        }

    }
}
