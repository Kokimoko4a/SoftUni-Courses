﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-RFLPA5C\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
