﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-RFLPA5C\SQLEXPRESS;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
