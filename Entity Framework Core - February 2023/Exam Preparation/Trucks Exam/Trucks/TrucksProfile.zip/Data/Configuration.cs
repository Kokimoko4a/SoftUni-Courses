﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-RFLPA5C\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}