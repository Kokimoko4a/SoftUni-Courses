﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-RFLPA5C\SQLEXPRESS;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
