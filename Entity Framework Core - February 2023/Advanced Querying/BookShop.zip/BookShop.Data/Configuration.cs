﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => @"Server=DESKTOP-RFLPA5C\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
