﻿namespace BookShop.Models.Enums
{
    public enum EditionType
    {
        Normal = 0,
        Promo = 1,
        Gold = 2
    }
}